
create database amazon_ecomm  --create databse

use amazon_ecomm --switch database 

-- indentity() - auto increment column
-- varchar: string (alpha-numeric)

create table category(cid int identity(1,1),catname varchar(10))

select * from category

insert into category(catname)
values('food')


drop table product
--
create table product
(pid int identity(1,1) primary key,
pname varchar(10) unique ,
pprice int not null,
sprice int not null
)

--
create table country
(cid int identity(1,1),
cname varchar(100)
)


-- drop table customer 
create table customer
(custidd int identity(1,1) primary key,
fname varchar(100) not null,
lname varchar(100) null,
emailid varchar(100) unique,
dob  datetime not null,
phoneno bigint unique,
cid   int,
gender  char(1) check (gender in('m','f')),
address varchar(100),
create_date datetime default getdate()
)

--
create table cart(
cartid int identity(1,1),
custid int,
pid int,
qty int,
draft_date datetime
)

--drop table sales_order
create table sales_order(
oid int identity(1,1) primary key,
custid int foreign key references customer(custidd),
odate datetime,
status_id int		--1 2 3 - 4 - 5 
)

create table sales_order_items(
iid int identity(1,1),
oid int,
pid int,
qty int,
price int,
status_id int
)

--
create table order_payment
(payid int identity(1,1),
oid int,
amt int,
paydate datetime,
status_id int
)

--
create table product_stock
(
sid int identity(1,1),
pid int,
qty int,
price int,
batch_no varchar(100),
mfd datetime,
expd datetime
)

category 2
insert into category(catname)
values('food')

select * from product  3 
select * from country  2
insert into country 
values('anaya'),
insert into country 
values('rohan')

select * from customer  5-10

insert into customer(fname,lname,emailid,dob,phoneno,cid,gender,address)
values('Richa','Rawat','richa@gmail.com',
'09/01/1990',8768965421,100,'M','Rajouri garden')


insert into customer(fname,lname,emailid,dob,phoneno,cid,gender,address)
values('Ridhi','Rawat','ridhi1@gmail.com',
'09/01/1991',9768965421,10,'F','Rajouri garden')


insert into customer(fname,lname,emailid,dob,phoneno,cid,gender,address)
values('rahul','sharma','rahul@gmail.com',
'09/01/1990',9768965421,100,'M','Rajouri garden')

insert into customer(fname,lname,emailid,dob,phoneno,cid,gender,address)
values('Raman','sinha','raman@gmail.com',
'09/01/1990',8768965422,100,'M','Rajouri garden')

insert into customer(fname,lname,emailid,dob,phoneno,cid,gender,address)
values('monika','sharma','monika@gmail.com',
'09/01/1990',8768965424,100,'F','Rajouri garden')

   5-10

insert into cart
values (1,1001,10,27/01/2020)
insert into cart
values (2,1002,11,27/01/2020)
insert into cart
values (3,1003,12,28/01/2020)
insert into cart
values (4,1004,13,28/01/2020)

select * from sales_order

select * from customer 

insert into sales_order
values (2,'06/01/2020',1)

insert into sales_order
values (4,06/01/2020,2)

insert into sales_order
values (8,07/01/2020,1)

insert into sales_order
values (1004,08/01/2020,4)
insert into sales_order
values (1005,06/01/2020,5)
  5-10
select * from sales_order_items

insert into sales_order_items
values(500,20,8,1000,1)

insert into sales_order_items
values(501,60,8,1019,2)

insert into sales_order_items
values(502,70,10,6000,5)
insert into sales_order_items
values(507,40,3,9000,1)

select * from order_payment 2 

insert into order_payment
values(1,3000,getdate(),1)


insert into order_payment
values(2,5000,getdate(),1)


select * from product_stock  4-5

insert into product_stock
values(1,10,40,'113',getdate(),null)

insert into product_stock
values(2,5,23000,'1313',getdate(),null)

select * from cart 
select * from customer


/*
data type :
	numeric:
		--without decimal
			tinint	2 byte 	
			int		4 byte	
			bigint  8 byte
		--with decimal 
			float	4 byte
						33.545					
			double	8 byte
						554.56666 (15 decimal)
			numeric(5,2)  = 123.45
	alpha numeric 
		 char		: fix size
					char(10)   ='a' , rest size will not be freed
		 nchar
		 varchar	: dynamic size 
					varchar(100) ='ab' ,rest size will be freed

				
		 nvarchar
		 text
					: file format data 
						,  xml  json  
		 ntext

		 Note:
				n - unicode(multiple language)
				  - consume double size of ascii 	 	
				not n- 	ascii (english)

		datetime
			date			yyyy-mm-dd
			datetime		yyyy-mm-dd hh:mm
			smalldatetime   yyyy-mm-dd hh:mm:ss:mis
		bit
			1 or 0

		varbinary :
					hexacode (encrypted code)
								
constraint:  is property of column or attribute which maintain the consistency of data
 There are following types 
	i. primary key
			- not null
			- no duplicate
			- physically sorted
						1 5 	
			- only one primary can be created on a table 							
	ii. unique 
			- single null
			- no duplicate 
			- multiple unique key can be created on a table
	iii. foreign key : is referential column from one (primary) table to another table
			- allow null
			- allow duplicate value
			- only those value which is present in first table
	iv.  not null
			- madatory field 
	v. null
			- option field 
	vi. check   : check in (gender in('m','f'))
			- allow value from given list 
	vii. default 
			- set value automatically when user will provide data 
			create_date  datetime default getdate()
			status int default 1
					
*/



select * from product 

insert into product 
values('Dove',40,45)

insert into product 
values('Iphone',40000,45000)
